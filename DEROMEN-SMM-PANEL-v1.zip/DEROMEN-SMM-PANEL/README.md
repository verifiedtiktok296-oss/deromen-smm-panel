# DEROMEN SMM PANEL

Mobile-first SMM panel starter. Phase 1 includes authentication, SQLite users/services/orders foundation, dashboard, services and orders UI.

## Run
pip install -r backend/requirements.txt
python backend/app.py
Open http://127.0.0.1:5000

Set SECRET_KEY before production. Provider API settings are placeholders until official API documentation/credentials are supplied.
